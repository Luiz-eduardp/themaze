# themaze
"Oliver é um garoto que não se lembrou dos ensinamentos de sua mãe e tomou a escolha errada, no labirinto ele entende que suas escolhas tem consequências."

Colete as lembranças e descubra a historia no void.


Up - Up Arrow / W  
Down - Down Arrow / S  
Left - Left Arrow / A  
Right - Right Arrow / D  
A - Alt / Z / J  
B - Ctrl / K / X  
Start - Enter  
Select - Shift  
